package aula_04;
//Declare duas maneiras de declarar um array unidimensional de 12 doubles.

public class Aula04_05 {
    public static void main(String[] args) {
        String [][] bidimensional ={{"emanoel","Lorenzo"},{"Leffa","Mittmann"}};
        System.out.println(bidimensional[0][1]+bidimensional[1][0]);
        System.out.println(bidimensional[0][0]+bidimensional[1][1]);

        String[][] outro = new String[1][1];
        double[] array1;

        double array2[];

        double[] array = new double[12];

    }
}
