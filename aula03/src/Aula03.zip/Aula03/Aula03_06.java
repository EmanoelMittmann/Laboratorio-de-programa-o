package Aula03;
/*6 - Crie uma classe que exiba o substring de uma string FRASE
 composto por todos os caracteres de FRASE exceto o último caracter.*/
public class Aula03_06 {
    public static void main(String[] args) {
        String nome = "texto";
        System.out.println(nome.substring(0, 4));
    }
}
